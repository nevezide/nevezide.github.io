// TODO : Play Here

console.log('Play With Me');

// TODO : Couverture
// La faire défiler de gauche à droite avec les flèches
// L'image est contenue dna sun élément qui a la classe .main-cover

// TODO : Les races de chat
// Afficher la bulle sur le chat au clic sur le bouton
// L'élément est accessible via la classe .race-chat-cover::after

// TODO : Les races de chat
// Changer la photo
// L'image est contenue dans un élément qui a la classe .race-chat-cover

// TODO : Les races de chat
// Dans la liste, Mettre en gras le Sacré de Birmanie et le Tigré
// La liste est accessible viala classe .race-chat-list
