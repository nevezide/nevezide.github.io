/**************************************************************/
/*                          Consigne                          */
/**************************************************************/
/*

Faire cet exercice en 2 temps :
 - D'abord la partie 1
 - Une fois que la partie 1 fonctionne, faire la partie 2

TODO :
- Implémenter l'algorithme présent dans le fichier MEP-2.svg

*/

/**************************************************************/
/*                        Main Program                        */
/**************************************************************/

// Le code de la partie 2 ici (copier/coller la partie 1 et remplacer la partie Sinon) ...
