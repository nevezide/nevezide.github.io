
export default ({
  name: 'Main',
  template: `
    <div class="main">
      <slot></slot>
    </div>
  `,
});
