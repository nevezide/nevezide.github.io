
// 1. Lorsque l'utilisateur clique sur le bouton "damier",
// Afficher un damier dans la grille

// TODO : Ajouter la classe .js-black sur les cases concernées


// 2. Lorsque l'utilisateur clique sur le bouton "disco",
// Afficher un dancefloor de lumières dans la grille

// TODO : Ajouter les classes .js-color1, ... .js-color6 aléatoirement


// 3. Lorsque l'utilisateur clique sur le bouton "labyrinth",
// Afficher le motif présent sur le bouton dans la grille

// TODO : Ajouter la classe .js-black sur les cases concernées


// 4. Lorsque l'utilisateur appuie sur une des 4 flèches du clavier,
// Afficher bobby et le déplacer sur le grille (de case en case)

// TODO : Ajouter la classe js-visible sur la div ayant l'id "bobby"
// Le déplacer de case en case (soit avec un pas de 3rem)
// dans la direction de la flèche appuyée
