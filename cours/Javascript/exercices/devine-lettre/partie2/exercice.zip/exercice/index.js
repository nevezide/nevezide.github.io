/**************************************************************/
/*                        Consignes                           */
/**************************************************************/
/*

Une fois que le joueur a trouvé la lettre, on lui propose de rejouer.

*/
/**************************************************************/
/*                            Data                            */
/**************************************************************/

let alphabet = "abcdefghijklmnopqrstuvwxyz";
let utilisateur = "";

/**************************************************************/
/*                        Main Program                        */
/**************************************************************/

// Tant que l'utilisateur veut continuer de jouer

  // Sélectionne une lettre au hasard dans l'alphabet (prendre le code de la partie 1)

  // Tant que l'utilisateur n'a pas trouvé la lettre

  // On affiche un message de bravo si l'utilisateur a trouvé la lettre

  // On demande à l'utilisateur si il veut continuer de jouer
