/**************************************************************/
/*                          Consigne                          */
/**************************************************************/
/*

Implémenter le célèbre jeu de chifoumi en trois manches.

Ajouter au code de la partie 1, la gestion des 3 manches.
Lors de chaque manche :
- Calculer le score de l'ordinateur et du joueur
- Afficher le score final

*/
/**************************************************************/
/*                         Variables                          */
/**************************************************************/

// Les variables à mettre ici...

/**************************************************************/
/*                        Main Program                        */
/**************************************************************/

// Le code du programme à écrire ici...
