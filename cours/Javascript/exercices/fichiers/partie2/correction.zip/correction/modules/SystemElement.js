class SystemElement {
  name;
  rights = 'rwx';

  constructor(name) {
    this.name = name;
  }
}

export default SystemElement;
