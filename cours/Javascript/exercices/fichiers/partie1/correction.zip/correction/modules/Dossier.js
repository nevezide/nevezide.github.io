import SystemElement from './SystemElement.js';

class Dossier extends SystemElement {
  constructor(name) {
    super(name);
  }
}

export default Dossier;
