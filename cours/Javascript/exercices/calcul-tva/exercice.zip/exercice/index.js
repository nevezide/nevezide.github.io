/**************************************************************/
/*                          Consigne                          */
/**************************************************************/
/*

Implémenter le code qui calcule le montant de la TVA
d'une liste de montants hors taxes.

// TODO
- Ecrire une fonction pour calculer le montant de la TVA :
elle prend un montant hors taxes en paramètre et retourne
le montant de la TVA calculée
- Ecrire le programme qui pour chaque élément du tableau
montantsHT affiche le montant de la TVA

*/
/**************************************************************/
/*                            Data                            */
/**************************************************************/

const TVA = 19.6;

const montantsHT = [12, 15, 20, 25, 30];

/**************************************************************/
/*                         Fonctions                          */
/**************************************************************/

// Le code de la fonction à écrire ici...

/**************************************************************/
/*                        Main Program                        */
/**************************************************************/

// Le code du programme à écrire ici...

/* Résultat attendu : console.log([
   2.352,
   2.94,
   3.92,
   4.9,
   5.88
 ])
*/
