/**************************************************************/
/*                         Consignes                          */
/**************************************************************/
/*

L'objectif de cet exercice est d'afficher la liste d'articles
dans un tableau HTML

*/
/**************************************************************/
/*                    !!! DO NOT EDIT !!!                     */
/**************************************************************/

let articles = [{
  name: 'Pantalon bleu',
  price: '100',
  quantity: 12
},{
  name: 'Pull over rouge',
  price: '75',
  quantity: 120
},{
  name: 'Chemise à carreaux',
  price: '35',
  quantity: 15
}];

/**************************************************************/
/*                          La vue                            */
/**************************************************************/

// Le code à implémenter ici...
