
// A partir des éléments présents dans toto,
// afficher le message suivant :

// Bonjour, je m'appelle Toto Dupont, j'ai 37 ans

let toto = {
  nom: "Dupont",
  prenom: "Toto",
  age: 37
};

// A toi de jouer !
