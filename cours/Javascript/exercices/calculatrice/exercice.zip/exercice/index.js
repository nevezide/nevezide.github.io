/**************************************************************/
/*                          Consigne                          */
/**************************************************************/
/*

L'objectif de cet exercice est de réaliser
une calculatrice 4 opérateurs : + - * /

TODO
- Demander à l'utilisateur d'entrer un premier nombre
- Demander à l'utilisateur d'entrer un opérateur
- Demander à l'utilisateur d'entrer un second nombre
- Vérifier que l'utilisateur a bien entré un nombre
(lui afficher un message si c'est pas le cas)
- Vérifier que l'utilisateur a bien entré un opérateur valide (+ - * /)
(lui afficher un message si c'est pas le cas)
- Effectuer l'opération demandée en fonction de l'opérateur
- Afficher le résultat de l'opération à l'utilisateur

*/
/**************************************************************/
/*                        Main Program                        */
/**************************************************************/

// Le code du programme à écrire ici...
