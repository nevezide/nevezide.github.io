/**************************************************************/
/*                         Consignes                          */
/**************************************************************/
/*

L'objectif de cet exercice est de réaliser un compteur de clics.
- Un bouton "Clique sur moi" qui incrémente le compteur
- Un bouton "Reset" qui réinitialise le compteur
- Un p qui affiche le compteur

*/
/**************************************************************/
/*                          La vue                            */
/**************************************************************/

// Le code sera implémenté ici.
