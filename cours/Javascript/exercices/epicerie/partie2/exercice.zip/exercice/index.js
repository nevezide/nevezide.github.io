/**************************************************************/
/*                          Consigne                          */
/**************************************************************/
/* 
Epicerie - Variante de la partie 1

On propose au client d'acheter un article tant qu'il y en a de disponibles

// TODO
Tant qu'il reste des articles différent de '',
exécuter le programme de la partie 1

*/
/**************************************************************/
/*                            Data                            */
/**************************************************************/

// DO NOT EDIT

const articles = [
  'Chips',
  'Saucisson',
  'Glace',
  'Fraises',
  'Vin',
  'Sucre',
  'Bière',
  'Mouchoirs'
];

/**************************************************************/
/*                        Main Program                        */
/**************************************************************/

// Le code sera implémenté ici...
