/* Epicerie - Variante de la partie 1
 * - On propose au client d'acheter un article
 *   tant qu'il y en a de disponibles
 */

const articles = [
  'Chips',
  'Saucisson',
  'Glace',
  'Fraises',
  'Vin',
  'Sucre',
  'Bière',
  'Mouchoirs'
];

// Tant qu'il reste des articles disponibles dans le tableau
// (cad qui n'ont pas été remplacés par une chaine vide '')

  // Afficher la liste des articles disponibles

  // Demander au client quel article il veut acheter

  // Vérifier si l'article est disponible en recherchant sa position dans la liste

  // Est-ce que l'article est disponible ?

    // OUI
      // Afficher "Ok"

      // Remplacer l'article par une chaine vide '' dans le tableau

      // Vérifier s'il reste des articles disponibles

    // NON
      // Afficher 'Article indisponible...'
