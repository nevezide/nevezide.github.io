/* 
  Algorithme à implémenter :
    - Faire 3 manches (en reprenant le code de la partie 1)
    - Afficher le score final des 3 manches à l'utilisateur
*/
