
// Déclaration des fonctions

function demanderNombres() {
    var nombres = [];
    nombres[0] = parseFloat(prompt("Entrez un nombre :"));
    nombres[1] = parseFloat(prompt("Entrez un second nombre :"));
    return nombres;
}

function afficherResultat(nombre1, nombre2, operateur, resultat) {
    alert("".concat(
      "Le résultat de l'opération ", nombre1, " ", operateur, " ", nombre2, " est ", resultat
    ));
}

function effectuerOperation(nombre1, nombre2, operateur) {
    var resultat = 0;
    switch (operateur) {
        case "+":
            resultat = nombre1 + nombre2;
            break;
        case "-":
            resultat = nombre1 - nombre2;
            break;
        case "*":
            resultat = nombre1 * nombre2;
            break;
        case "/":
            resultat = nombre1 / nombre2;
            break;
        case "%":
            resultat = nombre1 % nombre2;
            break;
    }
    return resultat;
}

// Programme principal

const operations = ["+", "*", "-", "/", "%"];

for(var i = 0; i < operations.length; i++) {
    var operation = operations[i];
    var nombres = demanderNombres();
    var resultat = effectuerOperation(nombres[0], nombres[1], operation);
    afficherResultat(resultat);
}
