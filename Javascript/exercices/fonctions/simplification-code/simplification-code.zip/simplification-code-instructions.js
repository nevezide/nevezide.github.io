/*
 * Simplification du code
 * 
 * Simplifier le code suivant en appliquant les bonnes pratiques de programmation, par exemple : 
 * - Utilisation de fonctions
 * - Aucune variable globale
 */

var nombre1 = 0;
var nombre2 = 0;
var resultat = 0;

// Demande à l'utilisateur d'entrer un nombre
nombre1 = parseFloat(prompt("Entrez un nombre :"));

// Demande à l'utilisateur d'entrer un second nombre
nombre2 = parseFloat(prompt("Entrez un second nombre :"));

// Multiplie les deux nombres
resultat = nombre1 * nombre2;

// Affiche le résultat
alert("".concat(
  "Le résultat de l'opération ", nombre1, " + ", nombre2, " est ", resultat
))

// Demande à l'utilisateur d'entrer un nombre
nombre1 = parseFloat(prompt("Entrez un nombre :"));

// Demande à l'utilisateur d'entrer un second nombre
nombre2 = parseFloat(prompt("Entrez un second nombre :"));

// Additionne les deux nombres
resultat = nombre1 + nombre2;

// Affiche le résultat
alert("".concat(
  "Le résultat de l'opération ", nombre1, " - ", nombre2, " est ", resultat
))

// Demande à l'utilisateur d'entrer un nombre
nombre1 = parseFloat(prompt("Entrez un nombre :"));

// Demande à l'utilisateur d'entrer un second nombre
nombre2 = parseFloat(prompt("Entrez un second nombre :"));

// Soustrait les deux nombres
resultat = nombre1 - nombre2;

// Affiche le résultat
alert("".concat(
  "Le résultat de l'opération ", nombre1, " - ", nombre2, " est ", resultat
))

// Demande à l'utilisateur d'entrer un nombre
nombre1 = parseFloat(prompt("Entrez un nombre :"));

// Demande à l'utilisateur d'entrer un second nombre
nombre2 = parseFloat(prompt("Entrez un second nombre :"));

// Divise les deux nombres
resultat = nombre1 / nombre2;

// Affiche le résultat
alert("".concat(
  "Le résultat de l'opération ", nombre1, " / ", nombre2, " est ", resultat
))

// Demande à l'utilisateur d'entrer un nombre
nombre1 = parseFloat(prompt("Entrez un nombre :"));

// Demande à l'utilisateur d'entrer un second nombre
nombre2 = parseFloat(prompt("Entrez un second nombre :"));

// Divise les deux nombres
resultat = nombre1 % nombre2;

// Affiche le résultat
alert("".concat(
  "Le résultat de l'opération ", nombre1, " % ", nombre2, " est ", resultat
))
