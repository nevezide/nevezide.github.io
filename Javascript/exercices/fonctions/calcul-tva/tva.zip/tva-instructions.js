/**
 * Implémenter le code qui calcule la TVA des montants ci-dessous :
 * - Utiliser une fonction pour calculer la TVA :
 * elle prend un montant en paramètre et retourne la TVA calculée
 */

const TVA = 19.6;

const montantsHT = [12, 15, 20, 25, 30];

/* Résultat attendu : console.log([
  14.352,
  17.94,
  23.92,
  29.9,
  35.88
])
*/
