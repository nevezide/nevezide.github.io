
const TVA = 19.6;

const montantsHT = [12, 15, 20, 25, 30];

function calculTva(montantsHT) {
  return montantsHT + (montantsHT * TVA / 100);
}

for(var i = 0; i < montantsHT.length; i++) {
  console.log(calculTva(montantsHT[i]));
}
