
const NB_MANCHES = 3;

function computerChoose() {
  var randomChoice = Math.round(Math.random() * 3);
  switch(randomChoice) {
    case 0:
      return 'feuille';
    case 1:
      return 'pierre';
    default:
      return 'ciseaux';
  }
}

function checkWhoWins(computerChoice, userChoice) {
  if (computerChoice === userChoice) {
    return 'egalite';
  }

  switch(userChoice) {
    case 'feuille':
      if (computerChoice === 'pierre') {
        return 'vous gagnez';
      } else {
        return 'ordinateur gagne';
      }
      break;
    case 'pierre':
      if (computerChoice === 'ciseaux') {
        return 'vous gagnez';
      } else {
        return 'ordinateur gagne';
      }
      break;
    case 'ciseaux':
      if (computerChoice === 'feuille') {
        return 'vous gagnez';
      } else {
        return 'ordinateur gagne';
      }
      break;
    }
}

function calculerScore(scores, resultat) {
    switch(resultat) {
        case 'ordinateur gagne':
            scores.ordinateur = scores.ordinateur + 1;
            break;
        case 'vous gagnez':
            scores.user = scores.user + 1;
            break;
    }
}

function afficherResultatFinal(scores) {
  if (scores.ordinateur > scores.user) {
    alert('Vous avez perdu');
  } else if (scores.ordinateur < scores.user) {
    alert('Vous avez gagné');
  } else {
    alert('égalité');
  }
}


// Algorithme principal

function jouer() {

  const scores = {
    ordinateur: 0,
    user: 0,
  };
  
  for (var i = 0; i < NB_MANCHES; i++) {
    // Choix de l'ordinateur
    var computerChoice = computerChoose();
  
    // Choix de l'utilisateur
    var userChoice = '';
    while (['pierre', 'feuille', 'ciseaux'].indexOf(userChoice) === -1) {
      userChoice = prompt("Choisissez entre feuille, pierre et ciseaux");
    }
  
    // Détermination du gagnant de la manche
    var resultat = checkWhoWins(computerChoice, userChoice);
  
    // Calcul du score total
    calculerScore(scores, resultat);
  
    // Affichage du résultat
    alert(
      "L'ordinateur a choisi " + 
      computerChoice +
      " et vous avez choisi " +
      userChoice +
      " donc " +
      resultat +
      ", score ordinateur - vous : " +
      scores.ordinateur +
      " - " +
      scores.user
    );
  }

  return scores;
}

// Les 3 manches réalisées, affichage résultat final
afficherResultatFinal(
  jouer()
);
