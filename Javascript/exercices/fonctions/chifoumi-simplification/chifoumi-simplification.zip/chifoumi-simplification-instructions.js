/*
 * Simplifier le code ci-dessous, en appliquant
 * les bonnes pratiques de programmation, par exemple :
 * - Utiliser des fonctions
 * - Aucune variable globale
 */

var computerChoice = '';
var userChoice = '';
var resultat = '';
var computerWins = 0;
var userWins = 0;

for (var i = 0; i < 3; i++) {

  var randomChoice = Math.round(Math.random() * 3);
  switch(randomChoice) {
    case 0:
      computerChoice = 'feuille';
      break;
    case 1:
      computerChoice = 'pierre';
      break;
    case 2:
      computerChoice = 'ciseaux';
      break;
  }

  userChoice = prompt("Choisissez entre feuille, pierre et ciseaux");

  if (computerChoice === userChoice) {
    resultat = 'égalité';
  } else {
    switch(userChoice) {
      case 'feuille':
        if (computerChoice === 'pierre') {
          resultat = 'vous gagnez';
          userWins++;
        } else {
          resultat = 'ordinateur gagne';
          computerWins++;
        }
        break;
      case 'pierre':
        if (computerChoice === 'ciseaux') {
          resultat = 'vous gagnez';
          userWins++;
        } else {
          resultat = 'ordinateur gagne';
          computerWins++;
        }
        break;
      case 'ciseaux':
        if (computerChoice === 'feuille') {
          resultat = 'vous gagnez';
          userWins++;
        } else {
          resultat = 'ordinateur gagne';
          computerWins++;
        }
        break;
      default:
        resultat = 'Vous devez choisir entre feuille, pierre et ciseaux';
        i--;
    }
  }

  alert(
    "L'ordinateur a choisi " + 
    computerChoice +
    " et vous avez choisi " +
    userChoice +
    " donc " +
    resultat +
    ", score ordinateur - vous : " +
    computerWins +
    " - " +
    userWins
  );
}
