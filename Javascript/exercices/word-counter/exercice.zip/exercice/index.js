/** Compte le nombre de mots commençant par s */

// Parcourir la liste de mots

  // Vérifie si la première lettre est égale à s
    // Si oui, incrémente le compteur

// Affiche le nombre de mots commençant par s
