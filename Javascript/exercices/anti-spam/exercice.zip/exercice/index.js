
let liste_blanche = [
  'larissa@gmail.com',
  'hacker44@gmail.com'
];

let email_recus = [{
  from: 'toto@gmail.com',
  content: 'Bonjour toi !',
},{
  from: 'larissa@gmail.com',
  content: 'Hé Salut !',
},{
  from: 'hacker44@gmail.com',
  content: 'Je suis un hacker !',
},{
  from: 'hacker@gmail.com',
  content: 'Piratage en cours...',
}];

let boite_reception = [];

// Pour chaque email reçu

  // Pour chaque email de la liste blanche

    // Vérifier si l'email reçu est dans la liste blanche

      // Si oui, l'ajouter dans le tableau "boite réception"

// Afficher le contenu de la boite de réception
