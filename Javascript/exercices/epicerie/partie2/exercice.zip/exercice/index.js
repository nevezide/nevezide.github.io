/* Epicerie - Variante de la partie 1
 * - On propose au client d'acheter un article
 *   tant qu'il y en a de disponibles
 */

const articles = [
  'Chips',
  'Saucisson',
  'Glace',
  'Fraises',
  'Vin',
  'Sucre',
  'Bière',
  'Mouchoirs'
];

// Tant qu'il reste des articles disponibles dans le tableau
// (cad qui n'ont pas été remplacés par une chaine vide '')

  // Afficher la liste des articles disponibles

  // Demande au client quel article il veut acheter

  // Vérifie si l'article est disponible
    // S'il est présent dans le tableau :
    // afficher "Ok" et le remplacer par une chaine vide '' dans le tableau

    // Sinon, afficher 'Article indisponible...'
