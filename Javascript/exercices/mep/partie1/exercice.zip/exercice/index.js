/*
 * Faire cet exercice en 2 temps :
 * - D'abord la partie 1
 * - Une fois que la partie 1 fonctionne, faire la partie 2
 */

// Partie 1 :
//   Demander à l'utilisateur quel est le jour de la semaine
//   Demander à l'utilisateur s'il y a une astreinte (OUI / NON)
//   Si : (le jour de la semaine est jeudi OU si le jour de la semaine est vendredi)
//         ET qu'il n'y a pas d'astreinte
//   Alors : afficher le message "Pas de MEP en fin de semaine"
//   Sinon : afficher le message "MEP Autorisée"
