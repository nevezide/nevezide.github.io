/*
 * Faire cet exercice en 2 temps :
 * - D'abord la partie 1
 * - Une fois que la partie 1 fonctionne, faire la partie 2
 */

// Partie 2 : Remplacer la partie "Sinon afficher le message "MEP Autorisée"" par
// Sinon :
//   Demander à l'utilisateur si les tests sont passés avec succès (OUI / NON)
//   Demander à l'utilisateur si le recette est passée avec succès (OUI / NON)
//   Si les tests sont passés avec succès ET que la recette est passée avec succès
//   Alors afficher le message "MEP Autorisée"
//   Sinon : afficher le message "Veuillez effectuer les corrections et rééssayez"

// ... Le code de la partie 2 ici (copier/coller la partie 1 et remplacer la partie Sinon)
